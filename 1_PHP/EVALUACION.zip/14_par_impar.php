<?php 
$numero =  24;
if ($numero%2==0){
echo "el $numero es par";
}else{
echo "el $numero es impar";
} 
?>