<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href= "css/stile.css" rel = "stylesheet">
</head>
<body> 
    <form method="post" action = "14_par_impar.php"> 
        <label for =">digite un  numero"> </label><br>
        <input type ="number" name="numero"><br>
        
         

        <input type= "submit" name="btn_enviar" value="ejecutar"> 

</form> 
</body> 
</html>